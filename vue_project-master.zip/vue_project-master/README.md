# vue_project

```
@author: Hliushi
@date:   2021年8月3日14:18:54
```

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Lints and fixes files

```
npm run lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).

```
安装 依赖
npm install vue-table-with-tree-grid@0.2.4
npm i vue-quill-editor@3.0.6
npm i lodash@4.17.11
npm i echarts@4.1.0
npm i nprogress@0.2.0
安装开发依赖
npm i babel-plugin-transform-remove-console@6.9.4 --save-dev
npm i @babel/plugin-syntax-dynamic-import@7.2.0 --save-dev
全局安装nodemon包
npm install -g nodemon
#
使用pm2管理应用
在服务器中安装pm2: npm i pm2 -g
启动项目: pm2 start 脚本 --name 自定义名称
查看运行项目: pm2 ls
重启项目: pm2 restart 自定义名称
停止项目: pm2 stop 自定义名称
删除项目: pm2 delete 自定义名称
```


