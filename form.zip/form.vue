<template>
  <div>
    <el-row :gutter="15">
      <el-form ref="elForm" :model="formData" :rules="rules" size="small" label-width="100px"
        label-position="left">
        <el-col :span="8">
          <el-form-item label="单行文本" prop="field101">
            <el-input v-model="formData.field101" placeholder="请输入单行文本单行文本" clearable
              :style="{width: '100%'}"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="7">
          <el-form-item label="单行文本" prop="field109">
            <el-input v-model="formData.field109" placeholder="请输入单行文本" clearable :style="{width: '100%'}">
            </el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="单行文本" prop="field110">
            <el-input v-model="formData.field110" placeholder="请输入单行文本" clearable :style="{width: '100%'}">
            </el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="单行文本" prop="field111">
            <el-input v-model="formData.field111" placeholder="请输入单行文本" clearable :style="{width: '100%'}">
            </el-input>
          </el-form-item>
        </el-col>
        <el-col :span="7">
          <el-form-item label="单行文本" prop="field112">
            <el-input v-model="formData.field112" placeholder="请输入单行文本" clearable :style="{width: '100%'}">
            </el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="下拉选择" prop="field114">
            <el-select v-model="formData.field114" placeholder="请选择下拉选择" clearable :style="{width: '100%'}">
              <el-option v-for="(item, index) in field114Options" :key="index" :label="item.label"
                :value="item.value" :disabled="item.disabled"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="日期范围" prop="field116">
            <el-date-picker type="daterange" v-model="formData.field116" format="yyyy-MM-dd"
              value-format="yyyy-MM-dd" :style="{width: '100%'}" start-placeholder="开始日期"
              end-placeholder="结束日期" range-separator="至" clearable></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item size="large">
            <el-button type="primary" @click="submitForm">提交</el-button>
            <el-button @click="resetForm">重置</el-button>
          </el-form-item>
        </el-col>
      </el-form>
    </el-row>
  </div>
</template>
<script>
export default {
  components: {},
  props: [],
  data() {
    return {
      formData: {
        field101: undefined,
        field109: undefined,
        field110: undefined,
        field111: undefined,
        field112: undefined,
        field114: undefined,
        field116: ["2021-09-24", "2021-10-11"],
      },
      rules: {
        field101: [{
          required: true,
          message: '请输入单行文本单行文本',
          trigger: 'blur'
        }],
        field109: [{
          required: true,
          message: '请输入单行文本',
          trigger: 'blur'
        }],
        field110: [{
          required: true,
          message: '请输入单行文本',
          trigger: 'blur'
        }],
        field111: [{
          required: true,
          message: '请输入单行文本',
          trigger: 'blur'
        }],
        field112: [{
          required: true,
          message: '请输入单行文本',
          trigger: 'blur'
        }],
        field114: [{
          required: true,
          message: '请选择下拉选择',
          trigger: 'change'
        }],
        field116: [{
          required: true,
          type: 'array',
          message: '请至少选择一个日期范围',
          trigger: 'change'
        }],
      },
      field114Options: [{
        "label": "选项一",
        "value": 1
      }, {
        "label": "选项二",
        "value": 2
      }],
    }
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {
    submitForm() {
      this.$refs['elForm'].validate(valid => {
        if (!valid) return
        // TODO 提交表单
      })
    },
    resetForm() {
      this.$refs['elForm'].resetFields()
    },
  }
}

</script>
<style>
</style>
